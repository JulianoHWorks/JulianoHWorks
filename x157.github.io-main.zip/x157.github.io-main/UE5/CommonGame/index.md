---
title: "Common Game Plugin"
description: "Overview of the Common Game Plugin for Unreal Engine 5"
breadcrumb_path: "UE5"
breadcrumb_name: "Common Game"
---

# Common Game Plugin

Common Game is one of the
[plugins distributed with Lyra](/UE5/LyraStarterGame/Plugins/).


<todo>TODO</todo>
