---
title: "Common Game Plugin"
description: "Overview of the Common Game Plugin for Unreal Engine 5"
breadcrumb_path: "UE5/CommonGame"
breadcrumb_name: "UGameUIManagerSubsystem"
---

# UGameUIManagerSubsystem

<todo>TODO</todo>
