---
title: "Humanoid Player Experience"
description: ""
breadcrumb_path: "/UE5/LyraStarterGame/Experience"
breadcrumb_name: "Humanoid Player"
---


# XCL Humanoid Player Experience

This is a 3rd person experience.  The player possesses a Humanoid Pawn.


# Humanoid Player Pawn Data

- Pawn Class = `AXCLHumanoidPlayerCharacter`
- Ability Set: `XAI_HumanoidPlayer_AbilitySet` (`ULyraAbilitySet`)
- Input Config: `XAI_HumanoidPlayer_InputConfig` (`ULyraInputConfig`)
- Camera Mode: `CM_ThirdPerson` *Lyra Default*


## TODO
