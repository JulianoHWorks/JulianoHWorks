---
title: "Lyra UI Manager Subsystem"
description: "How the Lyra UI Manager Subsystem is configured and how it works"
breadcrumb_path: "UE5/LyraStarterGame/Input"
breadcrumb_name: "UI Manager Subsystem"
---

# Lyra UI Manager Subsystem

The Lyra UI Manager Subsystem is based on the [Common Game](/UE5/CommonGame/) plugin's
[`UGameUIManagerSubsystem`](/UE5/CommonGame/UGameUIManagerSubsystem).

<TODO>TODO</TODO>

