---
sitemap: false
title: "Perforce Sync Procedure | UE5 Custom Engine"
description: "Xist's procedure for syncing from Epic's Perforce 5.1-Release Stream"
breadcrumb_path: "UE5/Engine"
breadcrumb_name: "Perforce Sync Procedure"
---

# Perforce Sync Procedure

This procedure is deprecated.  Epic has released Lyra on Github which changes how some of
this works, so I have reorganized it and moved this procedure to its new home:

[/UE5/LyraStarterGame/Tutorials/Procedure-Merge-Epic-Source-into-Git](/UE5/LyraStarterGame/Tutorials/Procedure-Merge-Epic-Source-into-Git)
